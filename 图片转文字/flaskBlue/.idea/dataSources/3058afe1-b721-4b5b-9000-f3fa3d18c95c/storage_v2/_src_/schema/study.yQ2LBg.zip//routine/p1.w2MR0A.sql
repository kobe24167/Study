create
    definer = root@localhost procedure p1(IN deptId varchar(100), OUT ids varchar(200), OUT dnames varchar(200),
                                          OUT codes varchar(200))
BEGIN
SET ids="qwd";
SET dnames="123";
SET codes="dgf";
END;

