create
    definer = root@localhost function f2(deptID varchar(200)) returns varchar(200)
BEGIN
	#通过部门ID找到ID路径
DECLARE p_id varchar(100);
DECLARE d_name varchar(100);
DECLARE path varchar(200);
SET p_id=deptID;
SET path='';
WHILE p_id IS NOT NULL
DO
SELECT dept_name, parent_id INTO d_name, p_id FROM t_dept WHERE dept_id = p_id;
SET path = CONCAT(path, '[', d_name, ']');
END WHILE;
RETURN path;
END;

